﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.AxHost;

namespace практическая_15_по_оа
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        PochtAdres adres=new PochtAdres();
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "")
            {
                MessageBox.Show("Есть пустые поля");
            }
            else 
            {
                int indexToSelect=listBox1.SelectedIndex;
                listBox1.SetSelected(indexToSelect, true);
                listBox1.Items[indexToSelect] = $"Улица: {textBox1.Text}, Город: {textBox2.Text}, Область: {textBox3.Text}, Код: {textBox4.Text}";
                /*string a = $"Улица: {textBox1.Text}, Город: {textBox2.Text}, Область: {textBox3.Text}, Код: {textBox4.Text}";*/
                string filePath = "pochta.txt";
                string[] lines = File.ReadAllLines(filePath);
                for (int i = 0; i < lines.Length; i++)
                {
                    if (lines[i].Contains(listBox1.Text))
                    {
                        lines[i] = $"Улица: {textBox1.Text}, Город: {textBox2.Text}, Область: {textBox3.Text}, Код: {textBox4.Text}";
                    }
                }
                File.WriteAllLines(filePath, lines);
            }
        }
            
        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            button3.Enabled = true;
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
             if (File.Exists("pochta.txt"))
             {
                 StreamReader sw = File.OpenText("pochta.txt");
                 while (!sw.EndOfStream)
                 {
                     string st = sw.ReadLine();
                     listBox1.Items.Add(st);
                 }
                 sw.Close();
             }
             else
             {
                MessageBox.Show("Файла нет");
             }
             button3.Enabled = false;
        }
    }
}
        